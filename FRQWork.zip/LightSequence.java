import java.lang.Math.*;

public class LightSequence {
  private String binary;

  public LightSequence(String seq) {
      this.binary = seq;
  }

  public String insertSegment(String segment, int ind) {
    String result = binary.substring(0, ind) + segment + binary.substring(ind);

    return result;
  }

  public void changeSequence(String newString) {
    this.binary = newString;
  }

  public void display() {
    System.out.println(binary);
  }

  public String replaceString(String oldSeq, String segment) {
    String newSeq = "";
    
    for (int i = 0; i < oldSeq.length() - segment.length(); i++) {
      String temp = oldSeq.substring(i, i + segment.length());

      if (temp.equals(segment)) {
        newSeq = oldSeq.substring(0, i) + oldSeq.substring(i + segment.length()+1);
        break;
      }
    }
    return newSeq;
  }

  public double distance(int a, int b) {
    return Math.sqrt(Math.pow(a, 2.0) + Math.pow(b, 2.0));
  }

}