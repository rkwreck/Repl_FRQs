import java.util.*;
/* completed */

class FRQ4 {
  public static void main(String[] args) {
    System.out.println("");
    System.out.println("Let's find the longest string in a string!");

    Scanner input = new Scanner(System.in);
    System.out.println("Enter string:");
    String str = input.nextLine();

    int count1 = 1;
    int count2 = 0; //max count (of the streak)
    char maxChar = str.charAt(0);
    for (int i = 0; i < str.length()-1; i++) {
        char char1= str.charAt(i);
        char char2= str.charAt(i+1);
        if(char1 == char2){
            count1 += 1;
        }
        else {  //if the streak ended 
            if (count1 > count2) {
                maxChar = char1; //new char
                count2 = count1;
            }
            count1 = 1;
        }
    }
    if (count1 > count2) {
        count2 = count1;
    }
    System.out.println(maxChar + " " + count2);
  System.out.println("");
}
}
