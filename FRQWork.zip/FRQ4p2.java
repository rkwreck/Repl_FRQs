import java.util.*;
/* completed */

class FRQ4p2 {
  private static int startingCoins = 10; // starting number of coins
  private static int maxRounds = 5; // maximum number of rounds played

  public FRQ4p2(int s, int r) {
    startingCoins = s;
    maxRounds = r;
  }

  public static int getPlayer1Move(int round) {
    int result;
    if (round % 3 == 0) {
      result = 3; 
    }
    else if (round % 2 == 0) {
      result = 2; 
    }
    else {
      result = 1; 
    }
    return result; 
    }

  public static int getPlayer2Move(int round) {
    int result;
    if (round % 3 == 0) {
      result = 3; 
    }
    else if (round % 2 == 0) {
      result = 2; 
    }
    else {
      result = 1; 
    }
    return result; 
    }

  public static void playGame() {
    int player1coins = startingCoins;
    int player2coins = startingCoins;
    int round = maxRounds;
        
    while (round != 0 || (player1coins >= 3 && player2coins >= 3)) {
      int player1spent = getPlayer1Move(round);
      int player2spent = getPlayer2Move(round);
            
      System.out.println("Round = "+round);
      System.out.println("Player 1 Spent = " + player1spent);
      System.out.println("Player 2 Spent = " + player2spent);
            
      if (player1spent == player2spent) {
        player2coins ++;
      }
      else if (Math.abs(player1spent - player2spent) == 1) {
        player2coins ++;
      }
      else if (Math.abs(player1spent - player2spent) == 2) { 
        player1coins += 2; 
      }
            
      player1coins -= player1spent;
      player2coins -= player2spent; 
            
      round --; 
    }
        
    if (player1coins == player2coins) {
      System.out.println("tie game"); 
    }
    else if (player1coins > player2coins) {
      System.out.println("Player 1 wins");
    }
        
    else if (player2coins > player1coins) {
      System.out.println("Player 2 wins");
    }
  }
    
  public static void main(String[] args) {
    playGame();
  }
}



