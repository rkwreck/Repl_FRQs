import java.util.*;
/* NumberSystem */
/* completed */ 

class FRQ10 {
  
  public FRQ10(){
    
  }

  public int gcf(int a, int b)
  { 
    if(b == 0)
    { 
      return a; 
    } 
    return gcf(b, a % b); 
        
  }
    
  public void reduceFraction(int numerator, int denominator)
  { 
    if(numerator % denominator == 0)
    {
      System.out.println("Reduced Fraction of " + numerator +"/" + denominator +" is : "+ numerator/denominator);
    }

    else
    {
      int common = gcf(numerator,denominator);
      int a = numerator/common;
      int b = denominator/common;
      System.out.println("Reduced Fraction of " + numerator +"/" + denominator +" is : "+ a +"/" + b);
    }
        
  }
    
  public static void main(String[] args)
  {
    System.out.println("");
    FRQ10 system = new FRQ10();
        
    System.out.println("GCF of 3 and 30 is :"+ system.gcf(3,30));
    System.out.println("GCF of 24 and 9 is :"+ system.gcf(24,9));
    System.out.println("GCF of 7 and 3 is :"+ system.gcf(7,3));
    System.out.println("");
    system.reduceFraction(30,3);
    system.reduceFraction(8,20);
    system.reduceFraction(24,9);
    system.reduceFraction(7,3);
    System.out.println("");
        
  }
}
