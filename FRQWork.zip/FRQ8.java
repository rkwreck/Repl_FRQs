import java.util.*;
/* ExperimentalFarm */
/* completed */

class FRQ8
{
  // instance variables - replace the example below with your own
  private Plot[][] farmPlots;

  public FRQ8(Plot[][] p)
  {
    // initialise instance variables
    farmPlots = new Plot[p.length][p[0].length];
    for (int i = 0; i < p.length; i++) 
    {
      for (int j = 0; j < p[0].length; j++) 
      {
        farmPlots[i][j]= p[i][j]; 
      }
    }
      
  }

  public Plot getHighestYield(String c)
  {
    int highestYield = 0;
    int maxRow = 0;
    int maxCol = 0;
    for (int i = 0; i < farmPlots.length; i++) 
    {
      for (int j = 0; j < farmPlots[0].length; j++) 
      {
        if (farmPlots[i][j].getCropType().equals(c)) 
        {
          if (highestYield < farmPlots[i][j].getCropYield()) 
          {
            highestYield = farmPlots[i][j].getCropYield();
            maxRow = i;
            maxCol = j; 
          }
        }
      }
    }
      
    return farmPlots[maxRow][maxCol];
  }
    
  public boolean sameCrop(int col)
  {
    String cropType = farmPlots[0][col].getCropType();
    for (int row = 0; row < farmPlots.length; row++)
    {
      if (!farmPlots[row][col].getCropType().equals(cropType)){
        return false;
      }
    }
    return true;
  }
    
  public static void main(String[] args) {
    System.out.println("");
    System.out.println("Let's figure out our highest yield on our farm is for corn.");

    Plot[][] myPlots = new Plot[4][3];
    
    myPlots[0][0] = new Plot("corn",20);
    myPlots[0][1] = new Plot("corn",30);
    myPlots[0][2] = new Plot("peas",10);
    
    myPlots[1][0] = new Plot("peas",30);
    myPlots[1][1] = new Plot("corn",40);
    myPlots[1][2] = new Plot("corn",62);
    
    myPlots[2][0] = new Plot("wheat",10);
    myPlots[2][1] = new Plot("corn",50);
    myPlots[2][2] = new Plot("rice",30);
    
    myPlots[3][0] = new Plot("corn",55);
    myPlots[3][1] = new Plot("corn",30);
    myPlots[3][2] = new Plot("peas",30);
    
    FRQ8 farm = new FRQ8(myPlots);
    Plot plot = farm.getHighestYield("corn");
    //Plot plot = farm.getHighestYield("peas");
    //Plot plot = farm.getHighestYield("rice");
    //Plot plot = farm.getHighestYield("wheat");

    System.out.println("Highest yield : " + plot.getCropYield()); 

    System.out.println(""); 
    System.out.println("Now let's see if we have the same type of crop planted in the same column.");
    
    System.out.println("Same crop: " + farm.sameCrop(2));
    System.out.println("Same crop: " + farm.sameCrop(1));
    System.out.println("Same crop: " + farm.sameCrop(0));

    System.out.println("");
  }
}

class Plot
{

    private String cropType;
    private int cropYield;

    public Plot(String crop, int yield)
    {
        cropType = crop;
        cropYield = yield;

    } 

    public String getCropType()
    {
        return cropType;
    }

    public int getCropYield()
    {   
        return cropYield;
    }  

}
