public class Invitation {
  private String hostName;
  private String address;

// constructor
  public Invitation(String hostname, String address) {
    this.hostName = hostname;
    this.address = address;
  }

//overloaded constructor
  public Invitation(String address) {
    this.address = address;
    hostName = "Host";
  } 
  
// getter
  public String host() {
    return hostName;
  }

// setter
  public void updateAddress(String updated) {
    this.address = updated;
    System.out.println("The address is " + address);
  }

  public String Letter(String invited) {
    return ("Dear " + invited + ", please attend my event at " + address + ". See you then, " + hostName);
  }

}