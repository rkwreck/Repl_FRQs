import java.util.*;
/* completed */
/* Words */

class FRQ6
{
  private int x;

  public FRQ6() 
  {
      x = 0;
  }

  public void printWords(String[] words,String endingWith)
  {
    int len = endingWith.length();
    for(String word: words)
    {
      int wordLen = word.length();
      if(endingWith.equals(word.substring(wordLen-len,wordLen))) {
        System.out.println(word);
      }      
    }
  }

  public static void main(String[] arg)
  {
    System.out.println("");

    String[] wordList = {"ten", "fading", "post", "card", "thunder", "hinge", "trailing", "batting"};

    System.out.println("Here are our words: " );
    
    for(String word: wordList)
    {
        System.out.println(word);
    }
    System.out.println("");
    System.out.println("Let's find all the words that end with -ing.");
    FRQ6 obj = new FRQ6();
    obj.printWords(wordList,"ing");

    System.out.println("");
  }
}
