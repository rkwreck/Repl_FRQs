/*
import java.util.ArrayList;

public class UserName {
  private ArrayList<String> possibleNames = new ArrayList<String>();

  public UserName(String firstname, String lastname) {
    possibleNames = new ArrayList<String>(); 
      for (int i = 1; i <= firstName.length(); i++) {
        possibleNames.add(lastName + firstName.substring(0, i)); 
    }   
  }

  public boolean isUsed(String name, String[] arr){ 
    for (int i = 0; i < arr.length; i++) {
      if (name.equals(arr[i])) {
        return true;
      }
    }
    return false; 
  }

  public void setAvailableUserNames(String[] usedNames){ 
    for (int i = 0; i < possibleNames.size(); i++) {
      String name = possibleNames.get(i);
      if (isUsed(name, usedNames) == true) {
        possibleNames.remove(i);
        //make sure all elements of possibleNames gets checked.
        // if a match is found, we want to decrement i so for loop increment will not skip next index.
        i--;  
      }
    }
  }

  public void getUserNames() {
    System.out.println("Possible usernames: ");
    for (String name : possibleNames) {
      System.out.println(name);
    }
  }

}
*/