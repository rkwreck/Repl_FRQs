import java.util.*;
/* UserName */
/* completed */

class FRQ7
{
  // The list of possible user names, based on a user’s first and last names and initialized by the constructor.
  private ArrayList<String> possibleNames;

  public FRQ7(String firstName, String lastName)
  { 
    possibleNames = new ArrayList<String>(); 
    for (int i = 1; i <= firstName.length(); i++) 
    {
      possibleNames.add(lastName + firstName.substring(0, i)); 
    }    
  }

  public boolean isUsed(String name, String[] arr)
  { 
    for (int i = 0; i < arr.length; i++) {
      if (name.equals(arr[i])) {
        return true;
       }
    }
    return false; 
  }

  public void setAvailableUserNames(String[] usedNames)
  { 
    for (int i = 0; i < possibleNames.size(); i++) 
    {
      String name = possibleNames.get(i);
      if (isUsed(name, usedNames) == true) 
      {
        possibleNames.remove(i);
        //make sure all elements of possibleNames gets checked.
        // if a match is found, we want to decrement i so for loop increment will not skip next index.
        i--;  
      }
    }
  }
    
  public void printNames() {
    System.out.println(possibleNames);
  }
      

  public static void main(String[] args)
  {
    System.out.println("");
    System.out.println("Let's figure out the usernames I can make for myself. I can't use an already-existing username.");
    System.out.println("");
    FRQ7 myName = new FRQ7("Rini", "Khandelwal");
    System.out.println("These are possible usernames I can take before checking if any are already taken:");
    myName.printNames();
    
    System.out.println("");
    //String[] myUsedNames = {"Khandelwal","KhandelwalR", "KhandelwalRi", "KhandelwalRini", "KhandelwalRin"};
    //String[] myUsedNames = {""};
    String[] myUsedNames = {"Khandelwal", "KhandelwalRi", "KhandelwalRini", "KhandelwalRin"};
    myName.setAvailableUserNames(myUsedNames);
    System.out.println("These are possible usernames I can take after checking which ones are already taken:");
    myName.printNames();  
    System.out.println("");
  }
}