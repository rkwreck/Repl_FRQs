import java.util.*;
/* completed */

class FRQ5 {
  public static void main(String[] args) {
    System.out.println("You're inviting someone for dinner. Let's write the invitation!");

    System.out.println("");

    Scanner input = new Scanner(System.in);
    System.out.println("Enter your name: ");
    String fromName = input.nextLine();

    //Scanner input = new Scanner(System.in);
    System.out.println("Enter the name of the person you are addressing: ");
    String toName = input.nextLine();


    //Invitation invite = new Invitation("Mary", "1234 Sesame Street");
    Invitation invite = new Invitation(fromName, "1234 Sesame Street");

    //answer a 
    String host = invite.host();
    System.out.println("The host is " + host);

    //answer b
    invite.updateAddress("123 Sesame Ave");

    //answer c
    //String letter = invite.Letter("Matthew");
    String letter = invite.Letter(toName);
    System.out.println(letter);


  }
}