import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    menu();
  }

  public static void menu() {
    int selection;
    Scanner sc = new Scanner(System.in);

    System.out.println("Choose FRQ to run:");
    System.out.println("1 - FRQ2");
    System.out.println("2 - FRQ3");
    System.out.println("3 - FRQ4");
    System.out.println("4 - FRQ4 part 2");
    System.out.println("5 - FRQ5");
    System.out.println("6 - FRQ6");
    System.out.println("7 - FRQ6 part 2");
    System.out.println("8 - FRQ7");
    System.out.println("9 - FRQ8");
    System.out.println("10 - FRQ9");
    System.out.println("11 - FRQ10");


    selection = sc.nextInt();

    switch(selection) {
      case 0:
        return;
      case 1:
        FRQ2.main(null);
        break;
      case 2:
        FRQ3.main(null);
        break;
      case 3:
        FRQ4.main(null);
        break;
      case 4:
        FRQ4p2.main(null);
        break;
      case 5:
        FRQ5.main(null);
        break;
      case 6:
        FRQ6.main(null);
        break;
      case 7:
        FRQ6p2.main(null);
        break;
      case 8:
        FRQ7.main(null);
        break;
      case 9:
        FRQ8.main(null);
        break;
      case 10:
        FRQ9p1.main(null);
        break;
      case 11:
        FRQ10.main(null);
        break;
    }
    menu();
  }
}