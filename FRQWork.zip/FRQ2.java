/* gradShow & LightSequence code */
/* completed */

import java.util.*;

class FRQ2 {
  public static void main(String[] args) {
    System.out.println("");
    System.out.println("In this FRQ, we'll be playing with sequences. Let's begin!"); 

    //answer a (create object with given sequence)
    LightSequence gradShow = new LightSequence("0101 0101 0101");
    
    //answer b (use display method to display object's sequence)
    System.out.println("");
    System.out.println("This is gradShow's current sequence: ");
    gradShow.display();

    //answer c (update gradShow light sequence)
    System.out.println("");
    System.out.println("Let's change gradShow's sequence: ");
    gradShow.changeSequence("0011 0011 0011");
    gradShow.display(); 
   
    //answer d (insert a segment at index 4)
    System.out.println("");
    System.out.println("Let's insert the segment '1111 1111' into gradShow's sequence.");
    String resultSeq =  gradShow.insertSegment("1111 1111", 4);
    System.out.println(resultSeq);
    
    //answer e (remove the first occurance of index from oldSeq)
    System.out.println("");
    System.out.println("Let's create a sequence and remove a part of it.");
    Scanner input = new Scanner(System.in);
    System.out.println("Enter your sequence: ");  //input
    String oldSeq = input.nextLine();
    System.out.println("Enter segment to be removed: "); //input
    String segment = input.nextLine();
    
    System.out.println(gradShow.replaceString(oldSeq, segment));

    //answer f (find the straight-line distance between two points)
    System.out.println("");
    System.out.println("Let's find the straight-line distance between two points.");
    System.out.println("Enter the value of point a: ");
    int a = input.nextInt();
    System.out.println("Enter the value of point b: ");
    int b = input.nextInt();
    System.out.println("The distance is " + gradShow.distance(a,b));  
    System.out.println("");

    //input.close();
 
  }
}

