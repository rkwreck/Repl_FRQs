import java.util.*;
/* Payroll */
/* completed */

class FRQ6p2
{  
  private int[] itemsSold; // number of items sold by each employee
  private double[] wages; // wages to be computed in part (b)

  public FRQ6p2(int[] items)
  {
    itemsSold = new int[items.length];
    wages = new double[items.length];
        
    for(int i =0;i<items.length;i++)
    {
      itemsSold[i] = items[i];
    }
        
  }

    public double computeBonusThreshold()
    {
      double min = itemsSold[0];
      double max = itemsSold[0];
      double sum = 0;
        
      for(int i=0;i<itemsSold.length;i++)
      {
        if(itemsSold[i] > max)
        {
            max = itemsSold[i];
        }
        if(itemsSold[i] < min)
        {
            min = itemsSold[i];
        }
        sum += itemsSold[i];
      }
        
      double threshold = (sum - min - max)/(itemsSold.length-2);
      return threshold;
    }
    
  public void computeWages(double fixedWage, double perItemWage)
  {
    double threshold = computeBonusThreshold();
    for(int i = 0;i<itemsSold.length;i++)
    {
        double wage = fixedWage + perItemWage*itemsSold[i];
        if(itemsSold[i] > threshold)
        {
            //Give 10% Bonus.
            wage = 1.1*wage;
            System.out.println("Employee " + i + " got Bonus !! ");
        }
        wages[i] = wage;
      }  
    }
    
    public void printWages()
    {
      System.out.println("");
      for(int i = 0;i<wages.length;i++)
      {
        System.out.println("Employee " + i + " wage is " + String.format("%.02f",wages[i]));
      }
    }
    
  public static void main(String[] arg)
  {
    System.out.println("");
    System.out.println("Let's figure out the sales: ");
    int[] sales = {48,50,37,62,38,70,55,37,64,60};
    int workers = 10;
    FRQ6p2 shop = new FRQ6p2(sales);
    System.out.println("Sales are: ");
    for(int i = 0;i<workers;i++)
    {
        System.out.println("Employee " + i + " sold " + sales[i] + " items");
    }
    System.out.println("");
    System.out.println("Bonus Threshold is " + shop.computeBonusThreshold());
    System.out.println("");
    shop.computeWages(10.0,1.5);
    shop.printWages(); 
    
    System.out.println("");
  }
    
}
