/*
public class Payroll {
  private int[] itemsSold;
  private double[] wages;

  public Payroll(int[] itemsSold) {
    this.itemsSold = itemsSold;
    int same = itemsSold.length;
    this.wages = new double[same];
  }

  public double computeBonusThreshold() {
    int min = 100;
    int max = 0;
    double total = 0;
    double count = 0;
    for (int item : itemsSold) {
      if (item < min) {
        min = item;
      }
      if (item > max) {
        max = item;
      }
      total += item;
      count++;
    }
    return (total - max - min) / count;
  }

  public void computeWages(double fixedWage, double perItemWage) {
    double threshold = computeBonusThreshold();
    int count = 0;
    for (int item : itemsSold) {
      double wage = fixedWage + (perItemWage * item);
      if (item > threshold) {
        wage = wage * 1.1;
      }
      wages[count] = wage;
      count++;
    }
    for (double employee : wages) {
      System.out.println(employee);
    }
  }
}
*/