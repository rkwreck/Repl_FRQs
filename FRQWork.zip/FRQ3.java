import java.util.*;
/* completed */

class FRQ3
{
  public static void main(String[] args) {
  System.out.println("");

  System.out.println("Hi! You've been invited to a dinner."); 

    //part a (check if someone is attending)
    Scanner input = new Scanner(System.in);
    boolean rsvp;
    System.out.println("Are you attending the dinner? Type 'y' if yes, or 'n' if no.");
    String answer = input.nextLine();

    if (answer.equals("y")) {
      rsvp = true; 
    }
    else {
      rsvp = false; 
    }

    //part b (food selection)
    System.out.println("Let's order some food. Choose a number from 1-4: ");
    System.out.println("1 - beef");
    System.out.println("2 - chicken");
    System.out.println("3 - pasta");
    System.out.println("4 - fish");
    int selection = input.nextInt(); //store the user's choice

    //part c (determine/acknowledge the user's selection & attendance)
    String option1 = " ";
    if (rsvp) {
      if (selection == 1) {
        option1 = ("Thanks for attending. You'll be served beef.");
        System.out.println(option1);

      }

      else if (selection == 2) {
        option1 = "Thanks for attending. You'll be served chicken.";
        System.out.println(option1);

      }

      else if (selection == 3) {
       option1 = "Thanks for attending. You'll be served pasta.";
       System.out.println(option1);

      }

      else {
       option1 = "Thanks for attending. You'll be served fish.";
       System.out.println(option1);
     }
    }
    else {
      option1 = "Sorry you can't make it.";
      System.out.println(option1);
    }
  System.out.println("");
}
}











/*
class FRQ3 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    boolean rsvp;
    System.out.println("Are you attending the dinner? (y/n): ");
    String answer = input.nextLine();
    // compare Strings and Objects using .equals()
    if (answer.equals("y")) {
      rsvp = true;
    }
    else {
      rsvp = false;
    }
    if (rsvp) {
      System.out.println("Choose a number between 1-4: ");
      System.out.println("1 - beef");
      System.out.println("2 - chicken");
      System.out.println("3 - pasta");
      System.out.println("4 - fish");
      int selection = input.nextInt();
      // compare int with ==, >, or <
      if (selection == 1) {
        System.out.println("Thanks for attending. You will be served beef.");
      }

      else if (selection == 2 ) {
        System.out.println("Thanks for attending. You will be served chicken.");
      }

      else if (selection == 3) {
        System.out.println("Thanks for attending. You will be served pasta.");
      }

      else {
        System.out.println("Thanks for attending. You will be served fish");
      }

    }
    else {
      System.out.println("Sorry you can't make it.");
    }

  }
}
*/