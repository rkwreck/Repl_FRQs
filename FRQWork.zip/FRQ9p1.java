import java.util.*;
/* completed */

class FRQ9p1 {
  String isCarnivoreOrHerbivore;
  String species;
  String name;
    
  public FRQ9p1(String animalType, String animalSpecies, String animalName)
  {
    isCarnivoreOrHerbivore = animalType;
    species = animalSpecies;
    name = animalName;
  }
 
  public String toString()
  {
    return name + " the " + species + " is " + isCarnivoreOrHerbivore;    
  }
    
  public static void main(String[] args)
  {   
    FRQ9p1 lisa = new FRQ9p1("carnivore", "lion", "Lisa");
    System.out.println(lisa.toString());
   
    Herbivore gary = new Herbivore("giraffe", "Gary");
    System.out.println(gary.toString());

    Elephant percy = new Elephant("Percy", 2.0);
    System.out.println(percy.toString());
       
  }
}

class Herbivore extends FRQ9p1
{
    public Herbivore(String animalSpecies, String animalName)
    {
        super("herbivore",animalSpecies,animalName);
    }
}

class Elephant extends Herbivore
{
    double tuskLength;
    public Elephant(String animalName, double length)
    {
        super("Elephant",animalName);
        tuskLength = length;
    }
    
    public String toString()
    {
        return super.toString() + " with tusk " + tuskLength + " meters long .";
        
    }
}

